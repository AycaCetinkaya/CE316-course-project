import sys

nums = [int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])]
nums.sort()

print(f"{nums[0]} {nums[1]} {nums[2]}")