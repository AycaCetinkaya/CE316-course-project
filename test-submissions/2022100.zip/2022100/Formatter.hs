module Formatter (formatList) where

import Data.List (intercalate)

formatList :: [Int] -> String
formatList xs = intercalate " " (map show xs)
