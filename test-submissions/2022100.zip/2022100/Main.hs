import System.Environment (getArgs)
import Sorter (sortList)
import Formatter (formatList)

main :: IO ()
main = do
    args <- getArgs
    let nums = map read args :: [Int]
    putStrLn (formatList (sortList nums))
