module Sorter (sortList) where

import Data.List (sort)

sortList :: [Int] -> [Int]
sortList = sort
