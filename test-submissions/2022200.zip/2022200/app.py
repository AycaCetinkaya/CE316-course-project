import sys
from sorter import sort_list
from formatter import format_list


def run(args):
    nums = [int(x) for x in args]
    return format_list(sort_list(nums))


if __name__ == "__main__":
    print(run(sys.argv[1:]))
