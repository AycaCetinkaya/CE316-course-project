def format_list(nums):
    return " ".join(str(n) for n in nums)
