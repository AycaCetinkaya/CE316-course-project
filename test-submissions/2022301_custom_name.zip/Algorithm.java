public class Algorithm {
    public static void main(String[] args) {
        System.out.println("Custom name file is working.");
    }
}
